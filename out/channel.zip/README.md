# Roku Krotov Labs Demo

I haven't worked with the Roku for years so I just wanted to create this quick demo up which references a couple video files feeds on my site and allows you to watch from within the Roku app.

# Feature I'm currently trying to figure out:

  - I wanted to run a simple CNN to perform facial recognition on the frame, but I am having an issue getting access to the individual frames themselves from BrightScript.
  - Once getting the frame, I can make async calls to REST api running model via roUrlTransfer and handle callback.